package com.example.trainappfinal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
